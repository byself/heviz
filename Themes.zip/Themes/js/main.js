(function(){

    scrollEvent();
    //监听页面滚动事件
    function scrollEvent() {

        var $head = $(".head");
        var $topnav = $(".topnav");
        var $foot = $(".foot");

        $(window).scroll(function (e) {
            // console.log("main:", scrollDirection);
            scrollFunc();
            if(scrollDirection == 'down'){
                $head.addClass("hide-head");
                $topnav.addClass("hide-head");
                $foot.addClass("hide-foot");
            }else if(scrollDirection == 'up'){
                $head.removeClass("hide-head");
                $topnav.removeClass("hide-head");
                $foot.removeClass("hide-foot");
            }

        });
    }


    var distance = 0;
    var scrollAction = {x: 0, y: 0}, scrollDirection;

    var winHeight = $(window).height();
    function scrollFunc() {

        var pageYOffset = window.scrollY;
        var docHeight = $(document).height();

        // console.log("pageYOffset:",window.scrollY);
        // console.log("docHeight:",docHeight);
        // console.log("winHeight:",winHeight);
        // console.log("winHeight2:",winHeight + pageYOffset < docHeight);

        if(pageYOffset >= 0 && (winHeight + pageYOffset < docHeight)){
            var diffY = scrollAction.y - pageYOffset;

            if (diffY < distance) {
                // Scroll down
                scrollDirection = 'down';
            } else if (diffY > distance) {
                // Scroll up
                scrollDirection = 'up';
            }

            scrollAction.y = pageYOffset;
        }


    }


})();



function toast(msg) {

    if ($(".toast").length) return;

    var delay = 1000;
    var html = '<div class="toast" style="z-index:999;position: absolute;left:0;right:0;top:0;bottom:0;margin:auto;width: 7rem;height:2rem;line-height:2rem;text-align:center;border-radius:1rem;font-size:.8rem;color:#FFF;background-color:rgba(0,0,0,.7);">' + msg + '</div>';
    var $html = $(html);
    $html.appendTo($("body"));

    setTimeout(function () {
        console.log("timeout");
        $html.remove();
        $html = null;
    }, delay);
}